Office Viewer 压缩包测试文件
本文件用于测试 zip 解压与目录浏览。
